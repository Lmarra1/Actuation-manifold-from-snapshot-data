import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import sys
from tensorflow.keras.callbacks import EarlyStopping

Normalize_data = 1
folderInput  = 'Input\\Train\\'
folderOutput = 'Output\\'

#Read actuation and sensor data
p1_data      = pd.read_csv(folderInput  + 'p1.txt')
p2_data      = pd.read_csv(folderInput  + 'p2.txt')
p3_data      = pd.read_csv(folderInput  + 'p3.txt')
v7125_data   = pd.read_csv(folderInput  + 'v7125.txt')
v10125_data  = pd.read_csv(folderInput  + 'v10125.txt')

#Read low-dimensional embedding coordinates
G1_data = pd.read_csv(folderInput +'G1.txt')
G2_data = pd.read_csv(folderInput +'G2.txt')
G3_data = pd.read_csv(folderInput +'G3.txt')
G4_data = pd.read_csv(folderInput +'G4.txt')
G5_data = pd.read_csv(folderInput +'G5.txt')

#Concatenate data
data = pd.concat([p1_data, p2_data, p3_data, v7125_data ,v10125_data, G1_data, G2_data, G3_data, G4_data, G5_data], axis=1)


'''random_int = np.random.choice(343, size=69, replace=False)
np.savetxt('IndicesValidData.txt', random_int)'''


with open('IndicesValidData.txt', 'r') as file:
    numbers = [int(float(line.strip())) for line in file.readlines()]
random_int = np.array(numbers, dtype=np.int32).reshape((69,))


train_data = []
Val_data   = []

# Split between training and validation data
for i in range(343):
    if i in random_int:
        aux_val = data.iloc[(i)*20:(i+1)*20, :]
        Val_data.append(aux_val)
    else:
        aux_train = data.iloc[(i)*20:(i+1)*20, :]
        train_data.append(aux_train)

train_data = np.vstack(train_data)
Val_data   = np.vstack(Val_data)
train_data = pd.DataFrame(train_data , columns= data.columns)
Val_data   = pd.DataFrame(Val_data   , columns= data.columns)

X_train = train_data[['p1', 'p2', 'p3', 'v7125', 'v10125']].values
Y_train = train_data[['G1', 'G2', 'G3', 'G4', 'G5']].values

X_val   = Val_data[['p1', 'p2', 'p3', 'v7125', 'v10125']].values
Y_val   = Val_data[['G1', 'G2', 'G3', 'G4', 'G5']].values



#Normalization of the data
if Normalize_data == 1:
   xtr_mean = np.mean(X_train, axis=0)
   ytr_mean = np.mean(Y_train, axis=0)
   xtr_std = np.sqrt(np.var(X_train, axis=0))
   ytr_std = np.sqrt(np.var(Y_train, axis=0))
   X_train = (X_train - xtr_mean) / xtr_std
   Y_train = (Y_train - ytr_mean) / ytr_std
   X_val = (X_val - xtr_mean) / xtr_std 
   Y_val = (Y_val - ytr_mean) / ytr_std 


# NN settings
early_stopping = EarlyStopping(monitor='val_loss', patience=400, restore_best_weights=True)

model = keras.Sequential([
    keras.layers.Dense(40, activation='tanh', input_shape=(5,)),
    keras.layers.Dense(40, activation='tanh'),
    keras.layers.Dense(5)
])

model.compile(optimizer='adam', loss='mean_squared_error')

# Training of NN model
history = model.fit(X_train, Y_train, epochs=15000, batch_size=2**10, validation_data=(X_val, Y_val), callbacks=[early_stopping])

# Evaluate on validation data
Y_pred = model.predict(X_val)

if Normalize_data == 1:
   Y_pred = Y_pred*ytr_std + ytr_mean
   Y_val = Y_val*ytr_std + ytr_mean

np.savetxt(folderOutput + 'ValidationGammas_trueMLP_2.txt', Y_val)
np.savetxt(folderOutput + 'ValidationGammas_predMLP_2.txt', Y_pred)

model.save('TrainedNN.keras')

if Normalize_data == 1:
    np.savetxt('normalization_data.txt', np.concatenate([xtr_mean, ytr_mean, xtr_std, ytr_std]))
    
with open('Normalize.txt', 'w') as f:
    f.write(str(Normalize_data))
    

# Results plot
plt.figure(figsize=(12, 6))

# Loss plot
plt.subplot(1, 2, 1)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.tight_layout()
plt.show()


for i in range(5):
    plt.figure(figsize=(8, 6))
    
    # Create a scatter plot of real test data vs. MLP output for the current output variable
    plt.scatter(Y_val[:, i] , Y_pred[:, i], alpha=0.5)
    
    # Plot the bisecting line (y = x)
    plt.plot([min(Y_val[:, i]), max(Y_val[:, i])], [min(Y_val[:, i]), max(Y_val[:, i])], color='red', linestyle='--')
    
    # Set labels and title for the current plot
    plt.xlabel(f'Real Validation Data (GAMMA {i+1})')
    plt.ylabel(f'MLP Output (GAMMA {i+1})')
    plt.title(f'Real Validation Data vs. MLP Output (GAMMA {i+1})')
    
    # Show the current plot
    plt.grid(True)
    plt.tight_layout()

plt.tight_layout()
plt.show()








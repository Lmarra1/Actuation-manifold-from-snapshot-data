import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import sys

# Load the saved model
loaded_model = keras.models.load_model('TrainedNN.keras')
normalization_data = np.loadtxt('normalization_data.txt', delimiter='\t')
xtr_mean, ytr_mean, xtr_std, ytr_std  = normalization_data[:5], normalization_data[5:10], normalization_data[10:15], normalization_data[15:20]
Normalize_data = np.loadtxt('Normalize.txt', delimiter='\t')



for Case2test in range(1,23):

    # Load the new dataset for testing
    folder_test = 'Input\\Test\\' + f'Case_{Case2test}\\'
    
    p1_test_data = pd.read_csv(folder_test     + 'p1.txt')
    p2_test_data = pd.read_csv(folder_test     + 'p2.txt')
    p3_test_data = pd.read_csv(folder_test     + 'p3.txt')
    Cl_test_data = pd.read_csv(folder_test     + 'Cl.txt')
    Cl_dl_test_data = pd.read_csv(folder_test  + 'Cl_dl.txt')

    # Combine the test data into a single DataFrame
    test_data = pd.concat([p1_test_data, p2_test_data, p3_test_data, Cl_test_data, Cl_dl_test_data], axis=1)
    X_test_new = test_data[['p1', 'p2', 'p3', 'Cl', 'Cl_dl']].values
    
    # Normalize the test data if needed (using the same mean and std as the training data)
    if Normalize_data == 1:
        X_test_new = (X_test_new - xtr_mean) / xtr_std
    
    # Evaluate the loaded model on the new test data
    Y_pred_new = loaded_model.predict(X_test_new)
    
    # If normalization was applied, reverse the normalization on predictions
    if Normalize_data == 1:
        Y_pred_new = Y_pred_new * ytr_std + ytr_mean
    
    # Combine X_test_new and Y_test_new into a single array
    test_data_new = np.column_stack((X_test_new))
    pred_data_new = np.column_stack((X_test_new, Y_pred_new))
    
    # Specify the file path for the new test data export
    output_file_test_new = f'Output\\Case_{Case2test}_' + 'test_dataMLP_1.txt'
    output_file_pred_new = f'Output\\Case_{Case2test}_' + 'pred_dataMLP_1.txt'
    
    # Save the new test data to a text file
    np.savetxt(output_file_test_new, test_data_new, delimiter='\t', header='p1\tp2\tp3\tCL\tCLdl')
    np.savetxt(output_file_pred_new, pred_data_new, delimiter='\t', header='p1\tp2\tp3\tCl\tCLdl\tG1\tG2\tG3\tG4\tG5')
    




    